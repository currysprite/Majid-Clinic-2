import { Link } from "@tanstack/react-router";
import { useState } from "react";

const navItems = [
  { to: "/about", label: "The Practice" },
  { to: "/services", label: "Clinical Scope" },
  { to: "/clinic", label: "Clinic" },
  { to: "/contact", label: "Contact" },
] as const;

export function SiteHeader() {
  const [open, setOpen] = useState(false);

  return (
    <>
      <header className="border-b border-border/60">
        <nav className="mx-auto flex max-w-7xl items-center justify-between px-6 py-8 md:px-8 md:py-10">
          <Link to="/" className="flex flex-col" onClick={() => setOpen(false)}>
            <span className="text-sm font-semibold uppercase tracking-[0.2em] text-navy">
              The Majid Practice
            </span>
            <span className="mt-1 text-[10px] uppercase tracking-widest text-ink-muted">
              Consultant Cardiology · Karachi
            </span>
          </Link>

          {/* Desktop nav */}
          <div className="hidden items-center gap-10 text-sm font-medium tracking-wide md:flex">
            {navItems.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                className="text-ink/80 transition-colors hover:text-accent"
                activeProps={{ className: "text-accent" }}
              >
                {item.label}
              </Link>
            ))}
            <Link
              to="/contact"
              className="bg-navy px-6 py-2.5 text-sm font-medium text-primary-foreground transition-colors hover:bg-accent"
            >
              Book Appointment
            </Link>
          </div>

          {/* Mobile hamburger */}
          <button
            className="flex flex-col gap-1.5 p-2 md:hidden"
            aria-label="Toggle menu"
            onClick={() => setOpen((v) => !v)}
          >
            <span className={`block h-px w-6 bg-navy transition-all duration-300 origin-center ${open ? "translate-y-[3.5px] rotate-45" : ""}`} />
            <span className={`block h-px w-6 bg-navy transition-all duration-300 ${open ? "opacity-0" : ""}`} />
            <span className={`block h-px w-6 bg-navy transition-all duration-300 origin-center ${open ? "-translate-y-[3.5px] -rotate-45" : ""}`} />
          </button>
        </nav>
      </header>

      {/* Mobile drawer */}
      {open && (
        <div className="fixed inset-0 z-50 md:hidden">
          <div className="absolute inset-0 bg-black/20" onClick={() => setOpen(false)} />
          <div className="absolute right-0 top-0 h-full w-72 bg-card shadow-2xl flex flex-col">
            <div className="flex items-center justify-between border-b border-border/60 px-6 py-8">
              <span className="text-sm font-semibold uppercase tracking-[0.2em] text-navy">
                The Majid Practice
              </span>
              <button onClick={() => setOpen(false)} aria-label="Close menu" className="text-ink-muted hover:text-navy text-lg">
                ✕
              </button>
            </div>
            <nav className="flex flex-col gap-1 px-4 pt-6">
              {navItems.map((item) => (
                <Link
                  key={item.to}
                  to={item.to}
                  onClick={() => setOpen(false)}
                  className="px-2 py-3 text-base font-medium text-ink/80 border-b border-border/40 hover:text-accent transition-colors"
                  activeProps={{ className: "px-2 py-3 text-base font-medium border-b border-border/40 text-accent" }}
                >
                  {item.label}
                </Link>
              ))}
            </nav>
            <div className="mt-auto px-6 pb-10">
              <Link
                to="/contact"
                onClick={() => setOpen(false)}
                className="block w-full bg-navy px-6 py-3.5 text-center text-sm font-medium uppercase tracking-widest text-primary-foreground transition-colors hover:bg-accent"
              >
                Book Appointment
              </Link>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
