import { Link } from "@tanstack/react-router";

export function SiteFooter() {
  return (
    <footer className="mt-32 border-t border-border/60 bg-linen/60">
      <div className="mx-auto grid max-w-7xl gap-12 px-6 py-16 md:grid-cols-4 md:px-8">
        <div className="md:col-span-2">
          <div className="text-sm font-semibold uppercase tracking-[0.2em] text-navy">
            The Majid Practice
          </div>
          <p className="mt-4 max-w-sm text-sm leading-relaxed text-ink-muted">
            Consultant cardiology and preventive cardiovascular medicine.
            Aga Khan University Hospital, Stadium Road, Karachi.
          </p>
        </div>

        <div>
          <p className="eyebrow mb-4">Practice</p>
          <ul className="space-y-2 text-sm">
            <li><Link to="/about" className="hover:text-accent">The Doctor</Link></li>
            <li><Link to="/services" className="hover:text-accent">Clinical Scope</Link></li>
            <li><Link to="/clinic" className="hover:text-accent">Clinic Information</Link></li>
            <li><Link to="/contact" className="hover:text-accent">Appointments</Link></li>
          </ul>
        </div>

        <div>
          <p className="eyebrow mb-4">Contact</p>
          <ul className="space-y-2 text-sm text-ink-muted">
            <li>+92 21 3486 0000</li>
            <li>appointments@majidpractice.pk</li>
            <li>Mon–Sat · 10:00–18:00</li>
          </ul>
        </div>
      </div>

      <div className="border-t border-border/60">
        <div className="mx-auto flex max-w-7xl flex-col items-start justify-between gap-3 px-6 py-6 text-xs text-ink-muted md:flex-row md:items-center md:px-8">
          <span>© {new Date().getFullYear()} The Majid Practice. All rights reserved.</span>
          <span className="tracking-widest uppercase">PMC Reg. No. 47821-K</span>
        </div>
      </div>
    </footer>
  );
}
