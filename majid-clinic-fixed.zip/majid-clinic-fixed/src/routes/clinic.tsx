import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";

export const Route = createFileRoute("/clinic")({
  head: () => ({
    meta: [
      { title: "Clinic Information — The Majid Practice" },
      {
        name: "description",
        content:
          "Clinic location, consulting hours, and contact details. Aga Khan University Hospital, Stadium Road, Karachi.",
      },
      { property: "og:title", content: "Clinic Information" },
      {
        property: "og:description",
        content:
          "Visit information for The Majid Practice — Stadium Road, Karachi.",
      },
    ],
  }),
  component: ClinicPage,
});

export default function ClinicPage() {
  return (
    <div className="min-h-dvh">
      <SiteHeader />

      <main className="mx-auto max-w-7xl px-6 pt-12 pb-24 md:px-8 md:pt-20">
        <header className="max-w-3xl">
          <p className="eyebrow">Clinic Information</p>
          <h1 className="mt-4 text-5xl font-medium leading-tight tracking-tight text-navy md:text-6xl">
            Visiting{" "}
            <span className="font-serif italic text-accent">the practice</span>.
          </h1>
        </header>

        <section className="mt-16 grid grid-cols-1 gap-12 lg:grid-cols-12">
          <div className="space-y-10 lg:col-span-7">
            <div className="border-t border-border pt-8">
              <p className="eyebrow">Address</p>
              <p className="mt-3 font-serif text-2xl italic text-navy">
                Consulting Clinics, Private Wing
              </p>
              <p className="mt-2 leading-relaxed text-ink-muted">
                Aga Khan University Hospital
                <br />
                Stadium Road, Karachi 74800
                <br />
                Sindh, Pakistan
              </p>
            </div>

            <div className="border-t border-border pt-8">
              <p className="eyebrow">Consulting Hours</p>
              <dl className="mt-4 divide-y divide-border">
                <div className="flex items-baseline justify-between py-3">
                  <dt className="text-sm font-medium text-navy">Monday — Wednesday</dt>
                  <dd className="text-sm text-ink-muted">10:00 — 14:00 · 17:00 — 20:00</dd>
                </div>
                <div className="flex items-baseline justify-between py-3">
                  <dt className="text-sm font-medium text-navy">Thursday</dt>
                  <dd className="text-sm text-ink-muted">10:00 — 14:00</dd>
                </div>
                <div className="flex items-baseline justify-between py-3">
                  <dt className="text-sm font-medium text-navy">Friday</dt>
                  <dd className="text-sm text-ink-muted">By appointment only</dd>
                </div>
                <div className="flex items-baseline justify-between py-3">
                  <dt className="text-sm font-medium text-navy">Saturday</dt>
                  <dd className="text-sm text-ink-muted">11:00 — 15:00</dd>
                </div>
                <div className="flex items-baseline justify-between py-3">
                  <dt className="text-sm font-medium text-navy">Sunday</dt>
                  <dd className="text-sm text-ink-muted">Closed</dd>
                </div>
              </dl>
            </div>
          </div>

          <aside className="lg:col-span-5">
            <div className="bg-card p-8 shadow-sm">
              <p className="eyebrow">Direct Contact</p>
              <ul className="mt-6 space-y-5 text-sm">
                <li>
                  <span className="block text-[11px] uppercase tracking-widest text-ink-muted">
                    Appointments
                  </span>
                  <span className="mt-1 block font-medium text-navy">
                    +92 21 3486 0000
                  </span>
                </li>
                <li>
                  <span className="block text-[11px] uppercase tracking-widest text-ink-muted">
                    Email
                  </span>
                  <span className="mt-1 block font-medium text-navy">
                    appointments@majidpractice.pk
                  </span>
                </li>
                <li>
                  <span className="block text-[11px] uppercase tracking-widest text-ink-muted">
                    Emergency
                  </span>
                  <span className="mt-1 block font-medium text-navy">
                    AKUH ER · +92 21 3493 0051
                  </span>
                </li>
              </ul>
              <p className="mt-8 text-xs leading-relaxed text-ink-muted">
                A new-patient consultation typically lasts 45 minutes.
                Please bring prior investigation reports, current
                prescriptions, and a list of concerns you wish to discuss.
              </p>
            </div>
          </aside>
        </section>
      </main>

      <SiteFooter />
    </div>
  );
}
