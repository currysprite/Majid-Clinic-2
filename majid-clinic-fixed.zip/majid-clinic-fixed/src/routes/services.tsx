import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";

export const Route = createFileRoute("/services")({
  head: () => ({
    meta: [
      { title: "Clinical Scope — The Majid Practice" },
      {
        name: "description",
        content:
          "Cardiology services offered: preventive cardiology, echocardiography, ETT, Holter monitoring, valvular disease management, and post-MI care.",
      },
      { property: "og:title", content: "Clinical Scope — Cardiology Services" },
      {
        property: "og:description",
        content:
          "Diagnostic and long-term cardiology care from Dr. Abdul Majid in Karachi.",
      },
    ],
  }),
  component: ServicesPage,
});

const services = [
  {
    no: "01",
    title: "Preventive Cardiology",
    body:
      "Comprehensive cardiovascular risk assessment, lipid management, and lifestyle-guided primary prevention for patients with a family history of heart disease, hypertension, or diabetes.",
  },
  {
    no: "02",
    title: "Echocardiography",
    body:
      "Transthoracic echocardiography performed and interpreted on-site, including assessment of left ventricular function, valvular pathology, and pulmonary pressures.",
  },
  {
    no: "03",
    title: "Exercise Tolerance Testing (ETT)",
    body:
      "Treadmill stress testing for the evaluation of effort-related chest pain, post-revascularisation surveillance, and pre-operative risk stratification.",
  },
  {
    no: "04",
    title: "24-Hour Holter & Ambulatory BP",
    body:
      "Continuous rhythm monitoring for the work-up of palpitations, syncope, and atrial fibrillation; 24-hour ambulatory blood pressure profiling.",
  },
  {
    no: "05",
    title: "Valvular Heart Disease",
    body:
      "Long-term medical management of mitral and aortic valve disease, including timing of surgical referral and post-operative follow-up.",
  },
  {
    no: "06",
    title: "Post-MI & Coronary Care",
    body:
      "Structured follow-up for patients after myocardial infarction or revascularisation — secondary prevention, anti-platelet management, and cardiac rehabilitation.",
  },
];

export default function ServicesPage() {
  return (
    <div className="min-h-dvh">
      <SiteHeader />

      <main className="mx-auto max-w-7xl px-6 pt-12 pb-24 md:px-8 md:pt-20">
        <header className="max-w-3xl">
          <p className="eyebrow">Clinical Scope</p>
          <h1 className="mt-4 text-5xl font-medium leading-tight tracking-tight text-navy md:text-6xl">
            A focused range of{" "}
            <span className="font-serif italic text-accent">cardiology services</span>.
          </h1>
          <p className="mt-8 text-lg leading-relaxed text-ink-muted">
            Each service below is delivered personally by Dr. Majid, with
            results reviewed and discussed in the same consultation
            wherever clinically appropriate. Procedures requiring inpatient
            facilities are coordinated through Aga Khan University Hospital.
          </p>
        </header>

        <section className="mt-20 grid grid-cols-1 gap-x-12 gap-y-16 md:grid-cols-2">
          {services.map((s) => (
            <article key={s.no} className="border-t border-border pt-8">
              <div className="flex items-baseline justify-between">
                <span className="font-mono text-xs uppercase tracking-widest text-ink-muted">
                  {s.no}
                </span>
                <span className="h-px w-16 bg-border" />
              </div>
              <h2 className="mt-6 text-2xl font-medium tracking-tight text-navy">
                {s.title}
              </h2>
              <p className="mt-4 leading-relaxed text-ink-muted">{s.body}</p>
            </article>
          ))}
        </section>
      </main>

      <SiteFooter />
    </div>
  );
}
