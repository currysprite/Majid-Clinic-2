import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import drMajid from "@/assets/dr-majid.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Dr. Abdul Majid — Consultant Cardiologist, Karachi" },
      {
        name: "description",
        content:
          "Private cardiology practice by Dr. Abdul Majid, MD, FCPS — Aga Khan University Hospital, Karachi. Preventive cardiology, echocardiography, and interventional care.",
      },
      { property: "og:title", content: "Dr. Abdul Majid — Consultant Cardiologist" },
      {
        property: "og:description",
        content:
          "Two decades of cardiovascular care rooted in the Aga Khan University tradition. Karachi.",
      },
    ],
  }),
  component: HomePage,
});

function HomePage() {
  return (
    <div className="min-h-dvh">
      <SiteHeader />

      <main className="mx-auto max-w-7xl px-6 pt-12 pb-24 md:px-8 md:pt-16 md:pb-32">
        {/* Hero */}
        <section className="grid grid-cols-1 gap-12 lg:grid-cols-12 lg:gap-16">
          <div className="lg:col-span-7 flex flex-col justify-center">
            <div className="mb-8 inline-flex items-center gap-4">
              <span className="h-px w-12 bg-navy/30" />
              <span className="eyebrow">MD · FCPS Cardiology · FACC</span>
            </div>

            <h1 className="text-5xl font-medium leading-[1.05] tracking-tight text-navy md:text-7xl">
              Dr. Abdul Majid
              <br />
              <span className="font-serif italic text-4xl text-accent md:text-6xl">
                Cardiovascular Medicine
              </span>
            </h1>

            <p className="mt-8 max-w-[55ch] text-lg leading-relaxed text-ink-muted">
              Two decades of clinical discipline, rooted in the Aga Khan
              University tradition. Personalised, evidence-based cardiology
              for the discerning patient in Karachi.
            </p>

            <div className="mt-12 flex flex-wrap items-center gap-6">
              <Link
                to="/contact"
                className="bg-navy px-7 py-3.5 text-sm font-medium tracking-wide text-primary-foreground transition-colors hover:bg-accent"
              >
                Book an Appointment
              </Link>
              <Link
                to="/about"
                className="border-b border-navy/30 pb-1 text-sm font-medium text-navy transition-colors hover:border-navy"
              >
                About the Doctor
              </Link>
            </div>
          </div>

          <div className="relative lg:col-span-5">
            <div className="relative aspect-[4/5] overflow-hidden bg-muted">
              <img
                src={drMajid}
                alt="Portrait of Dr. Abdul Majid"
                width={800}
                height={1000}
                className="h-full w-full object-cover grayscale-[0.25] transition-all duration-700 hover:grayscale-0"
              />
              <div className="absolute inset-0 ring-1 ring-inset ring-black/5" />
            </div>
            <div className="absolute -bottom-6 -left-4 max-w-xs bg-card p-7 shadow-xl shadow-navy/5 md:-bottom-8 md:-left-8">
              <p className="eyebrow mb-3">Appointments</p>
              <ul className="space-y-3">
                <li className="academic-border pb-2">
                  <span className="block text-xs font-medium">
                    Aga Khan University Hospital
                  </span>
                  <span className="text-[10px] text-ink-muted">
                    Consultant Cardiologist
                  </span>
                </li>
                <li className="academic-border pb-2">
                  <span className="block text-xs font-medium">
                    Pakistan Cardiac Society
                  </span>
                  <span className="text-[10px] text-ink-muted">
                    Senior Fellow
                  </span>
                </li>
              </ul>
            </div>
          </div>
        </section>

        {/* Metrics */}
        <section className="mt-32 grid grid-cols-2 gap-10 border-t border-border pt-12 md:grid-cols-4">
          {[
            { v: "22+", l: "Years of Clinical Practice" },
            { v: "9,400", l: "Patients Cared For" },
            { v: "31", l: "Peer-Reviewed Publications" },
            { v: "97.8%", l: "Procedural Success" },
          ].map((m) => (
            <div key={m.l}>
              <span className="block font-serif text-3xl tabular-nums text-navy">
                {m.v}
              </span>
              <span className="mt-2 block text-[11px] uppercase tracking-widest text-ink-muted">
                {m.l}
              </span>
            </div>
          ))}
        </section>

        {/* Brief intro */}
        <section className="mt-32 grid grid-cols-1 gap-12 lg:grid-cols-12">
          <div className="lg:col-span-4">
            <p className="eyebrow">Practice Philosophy</p>
            <h2 className="mt-4 font-serif text-4xl italic text-navy">
              Quiet rigour, considered care.
            </h2>
          </div>
          <div className="lg:col-span-7 lg:col-start-6 space-y-6 text-lg leading-relaxed text-ink-muted">
            <p>
              The practice is built on a single principle: cardiovascular
              decisions deserve unhurried attention. Each consultation is
              allocated the time required for thorough history-taking,
              targeted investigation, and a frank conversation about
              treatment.
            </p>
            <p>
              Dr. Majid's clinical interests centre on preventive
              cardiology, valvular disease, and the long-term management of
              coronary artery disease — with a particular focus on
              risk-stratified care for patients in midlife and beyond.
            </p>
            <Link
              to="/services"
              className="inline-block border-b border-navy/30 pb-1 text-sm font-medium text-navy hover:border-navy"
            >
              Explore the clinical scope →
            </Link>
          </div>
        </section>
      </main>

      <SiteFooter />
    </div>
  );
}
