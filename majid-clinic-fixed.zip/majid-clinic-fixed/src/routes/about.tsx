import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import drMajid from "@/assets/dr-majid.jpg";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About — Dr. Abdul Majid, Consultant Cardiologist" },
      {
        name: "description",
        content:
          "Aga Khan University trained consultant cardiologist with over two decades of clinical practice in Karachi. Credentials, training, and academic appointments.",
      },
      { property: "og:title", content: "About Dr. Abdul Majid" },
      {
        property: "og:description",
        content:
          "Education at Aga Khan University, residency at Jinnah Postgraduate Medical Centre, fellowship at Tabba Heart Institute.",
      },
    ],
  }),
  component: AboutPage,
});

const timeline = [
  {
    year: "1995 — 1997",
    title: "Pre-Medical (FSc)",
    org: "Adamjee Government Science College, Karachi",
    note: "Pre-medical group, first division.",
  },
  {
    year: "1997 — 2002",
    title: "MBBS",
    org: "Aga Khan University Medical College, Karachi",
    note: "Graduated with distinction in Internal Medicine.",
  },
  {
    year: "2003 — 2007",
    title: "Internal Medicine Residency",
    org: "Jinnah Postgraduate Medical Centre, Karachi",
    note: "Chief resident, final year.",
  },
  {
    year: "2007 — 2010",
    title: "Cardiology Fellowship",
    org: "Tabba Heart Institute, Karachi",
    note: "Echocardiography & interventional cardiology.",
  },
  {
    year: "2011",
    title: "FCPS — Cardiology",
    org: "College of Physicians and Surgeons Pakistan",
  },
  {
    year: "2014",
    title: "Fellowship, American College of Cardiology (FACC)",
    org: "Washington, D.C.",
  },
  {
    year: "2016 — Present",
    title: "Consultant Cardiologist",
    org: "Aga Khan University Hospital, Karachi",
  },
];

const memberships = [
  "Pakistan Cardiac Society — Senior Fellow",
  "American College of Cardiology — Fellow (FACC)",
  "European Society of Cardiology — Member",
  "College of Physicians and Surgeons Pakistan — Fellow",
];

export default function AboutPage() {
  return (
    <div className="min-h-dvh">
      <SiteHeader />

      <main className="mx-auto max-w-7xl px-6 pt-12 pb-24 md:px-8 md:pt-20">
        <div className="grid grid-cols-1 gap-16 lg:grid-cols-12">
          <div className="lg:col-span-5">
            <div className="aspect-[4/5] overflow-hidden bg-muted">
              <img
                src={drMajid}
                alt="Dr. Abdul Majid"
                width={800}
                height={1000}
                loading="lazy"
                className="h-full w-full object-cover grayscale-[0.2]"
              />
            </div>
          </div>

          <div className="lg:col-span-7">
            <p className="eyebrow">The Doctor</p>
            <h1 className="mt-4 text-5xl font-medium leading-tight tracking-tight text-navy md:text-6xl">
              Dr. Abdul Majid,{" "}
              <span className="font-serif italic text-accent">MD, FCPS, FACC</span>
            </h1>
            <p className="mt-8 text-lg leading-relaxed text-ink-muted">
              Dr. Abdul Majid is a Karachi-based consultant cardiologist
              with twenty-two years of clinical practice. His training
              follows a deliberate path through Pakistan's most demanding
              institutions — from Aga Khan University Medical College
              through residency at Jinnah Postgraduate Medical Centre and
              fellowship at the Tabba Heart Institute.
            </p>
            <p className="mt-4 text-lg leading-relaxed text-ink-muted">
              His clinical interests include preventive cardiology, the
              non-invasive evaluation of coronary disease, and the
              long-term medical management of valvular and structural
              heart disease. He maintains a teaching appointment at
              Aga Khan University and lectures regularly at national
              cardiology meetings.
            </p>
          </div>
        </div>

        {/* Timeline */}
        <section className="mt-32">
          <p className="eyebrow">Training & Appointments</p>
          <h2 className="mt-3 font-serif text-4xl italic text-navy">
            A considered education.
          </h2>
          <ol className="mt-12 border-t border-border">
            {timeline.map((t) => (
              <li
                key={t.year + t.title}
                className="grid grid-cols-1 gap-4 border-b border-border py-6 md:grid-cols-12"
              >
                <span className="font-mono text-xs uppercase tracking-widest text-ink-muted md:col-span-3">
                  {t.year}
                </span>
                <div className="md:col-span-9">
                  <p className="text-lg font-medium text-navy">{t.title}</p>
                  <p className="text-sm text-ink-muted">{t.org}</p>
                  {t.note && (
                    <p className="mt-1 text-sm italic text-ink-muted/80">
                      {t.note}
                    </p>
                  )}
                </div>
              </li>
            ))}
          </ol>
        </section>

        {/* Memberships */}
        <section className="mt-24 grid grid-cols-1 gap-12 lg:grid-cols-12">
          <div className="lg:col-span-4">
            <p className="eyebrow">Professional Memberships</p>
            <h2 className="mt-3 font-serif text-3xl italic text-navy">
              Societies & fellowships.
            </h2>
          </div>
          <ul className="lg:col-span-7 lg:col-start-6 space-y-3 text-base text-ink">
            {memberships.map((m) => (
              <li key={m} className="academic-border pb-3">
                {m}
              </li>
            ))}
          </ul>
        </section>
      </main>

      <SiteFooter />
    </div>
  );
}
