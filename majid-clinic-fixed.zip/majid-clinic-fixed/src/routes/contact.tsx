import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import { useState } from "react";
import { z } from "zod";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Request an Appointment — The Majid Practice" },
      {
        name: "description",
        content:
          "Request a consultation with Dr. Abdul Majid. Submit your name, phone, reason for visit, and preferred time.",
      },
      { property: "og:title", content: "Request an Appointment" },
      {
        property: "og:description",
        content: "Book a consultation with Dr. Abdul Majid in Karachi.",
      },
    ],
  }),
  component: ContactPage,
});

const contactSchema = z.object({
  name: z.string().trim().min(2, "Please enter your full name").max(100),
  phone: z
    .string()
    .trim()
    .min(7, "Please enter a valid phone number")
    .max(20),
  reason: z.string().trim().min(5, "Please describe the reason briefly").max(500),
  preferred: z.string().trim().max(100).optional().or(z.literal("")),
});

type FormErrors = Partial<Record<keyof z.infer<typeof contactSchema>, string>>;

export default function ContactPage() {
  const [errors, setErrors] = useState<FormErrors>({});
  const [submitted, setSubmitted] = useState(false);

  const onSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const result = contactSchema.safeParse({
      name: fd.get("name"),
      phone: fd.get("phone"),
      reason: fd.get("reason"),
      preferred: fd.get("preferred") ?? "",
    });
    if (!result.success) {
      const fieldErrors: FormErrors = {};
      for (const issue of result.error.issues) {
        const k = issue.path[0] as keyof FormErrors;
        if (!fieldErrors[k]) fieldErrors[k] = issue.message;
      }
      setErrors(fieldErrors);
      return;
    }
    setErrors({});
    setSubmitted(true);
  };

  return (
    <div className="min-h-dvh">
      <SiteHeader />

      <main className="mx-auto max-w-7xl px-6 pt-12 pb-24 md:px-8 md:pt-20">
        <header className="max-w-3xl">
          <p className="eyebrow">Appointments</p>
          <h1 className="mt-4 text-5xl font-medium leading-tight tracking-tight text-navy md:text-6xl">
            Request a{" "}
            <span className="font-serif italic text-accent">consultation</span>.
          </h1>
          <p className="mt-8 text-lg leading-relaxed text-ink-muted">
            Complete the form below and the practice secretary will return
            your enquiry within one working day to confirm a suitable time.
            For urgent matters, please call the clinic directly on{" "}
            <span className="text-navy">+92 21 3486 0000</span>.
          </p>
        </header>

        <section className="mt-16 grid grid-cols-1 gap-12 lg:grid-cols-12">
          <div className="lg:col-span-7">
            {submitted ? (
              <div className="border-t border-border pt-10">
                <p className="eyebrow text-accent">Received</p>
                <h2 className="mt-3 font-serif text-3xl italic text-navy">
                  Thank you — your request has been noted.
                </h2>
                <p className="mt-4 text-ink-muted">
                  The practice will be in touch shortly to confirm your
                  appointment.
                </p>
              </div>
            ) : (
              <form onSubmit={onSubmit} className="space-y-8 border-t border-border pt-10" noValidate>
                <Field
                  label="Full name"
                  name="name"
                  required
                  error={errors.name}
                />
                <Field
                  label="Phone number"
                  name="phone"
                  type="tel"
                  required
                  error={errors.phone}
                />
                <Field
                  label="Reason for visit"
                  name="reason"
                  textarea
                  required
                  error={errors.reason}
                />
                <Field
                  label="Preferred day or time (optional)"
                  name="preferred"
                  placeholder="e.g. Tuesday afternoon"
                  error={errors.preferred}
                />

                <button
                  type="submit"
                  className="bg-navy px-8 py-3.5 text-sm font-medium tracking-wide text-primary-foreground transition-colors hover:bg-accent"
                >
                  Submit Request
                </button>
              </form>
            )}
          </div>

          <aside className="lg:col-span-4 lg:col-start-9">
            <div className="bg-card p-8 shadow-sm">
              <p className="eyebrow">Direct Lines</p>
              <ul className="mt-6 space-y-5 text-sm">
                <li>
                  <span className="block text-[11px] uppercase tracking-widest text-ink-muted">
                    Practice Secretary
                  </span>
                  <span className="mt-1 block font-medium text-navy">
                    +92 21 3486 0000
                  </span>
                </li>
                <li>
                  <span className="block text-[11px] uppercase tracking-widest text-ink-muted">
                    Email
                  </span>
                  <span className="mt-1 block font-medium text-navy">
                    appointments@majidpractice.pk
                  </span>
                </li>
                <li>
                  <span className="block text-[11px] uppercase tracking-widest text-ink-muted">
                    Hours
                  </span>
                  <span className="mt-1 block font-medium text-navy">
                    Mon — Sat · 10:00–18:00
                  </span>
                </li>
              </ul>
            </div>
          </aside>
        </section>
      </main>

      <SiteFooter />
    </div>
  );
}

function Field({
  label,
  name,
  type = "text",
  textarea = false,
  required = false,
  placeholder,
  error,
}: {
  label: string;
  name: string;
  type?: string;
  textarea?: boolean;
  required?: boolean;
  placeholder?: string;
  error?: string;
}) {
  const baseClass =
    "mt-3 block w-full border-0 border-b border-border bg-transparent px-0 py-3 text-base text-navy placeholder:text-ink-muted/50 focus:border-accent focus:outline-none focus:ring-0";
  return (
    <div>
      <label htmlFor={name} className="eyebrow">
        {label}
        {required && <span className="ml-1 text-accent">*</span>}
      </label>
      {textarea ? (
        <textarea
          id={name}
          name={name}
          rows={4}
          placeholder={placeholder}
          className={baseClass}
        />
      ) : (
        <input
          id={name}
          name={name}
          type={type}
          placeholder={placeholder}
          className={baseClass}
        />
      )}
      {error && (
        <p className="mt-2 text-xs text-destructive">{error}</p>
      )}
    </div>
  );
}
